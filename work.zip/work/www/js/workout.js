var taskList = new Array();
var workOut = new Array();

function reset()
{
	window.localStorage.clear();
	alert("App has been Reset");
}

function showall(){

	var $taskList = $('#taskList');
	//checking if local storage is competable with browser
	if(window.localStorage)
	{
		taskList = JSON.parse(window.localStorage.getItem('taskList'));
	}
	
	//checking if array is empty
	if(null !== taskList)
	{
	//display buttons
		for(var i=0;i<=taskList.length;i++)
		{
			if(taskList[i].done == true)
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
		}
	}
	else
	{
		//number of days
		var N  = 30;
		taskList = new Array();
		
		for(var i=0;i<=N;i++)
		{
		    var $day = "day" + i.toString();
			taskList.push({day:$day,done:false});
			if(window.localStorage)
			{
				window.localStorage.setItem('taskList',JSON.stringify(taskList));
			}
		}
		
		//Display buttons
		if(taskList[i].done == true )
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)"> data-transition="flip" data-direction="reverse"' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
	}
	;$("#taskList").empty();
    showalll();
	
	/*
	alert("op");
	//make only one button click function with many conditionals
	$('#day').on('click',function(){
		//redirect
		alert("button");
	});
	
	$('#box').on('click',function(){
		alert("check and uncheck");
	});
	
*/
}

function showalll(){

	var $taskList = $('#taskList');
	//checking if local storage is competable with browser
	if(window.localStorage)
	{
		taskList = JSON.parse(window.localStorage.getItem('taskList'));
	}
	
	//checking if array is empty
	if(null !== taskList)
	{
	//display buttons
		for(var i=0;i<=taskList.length;i++)
		{
			if(taskList[i].done == true )
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
		}
	}
	else
	{
		//number of days
		var N  = 30;
		taskList = new Array();
		
		for(var i=0;i<=N;i++)
		{
		    var $day = "day" + i.toString();
			taskList.push({day:$day,done:true});
			if(window.localStorage)
			{
				window.localStorage.setItem('taskList',JSON.stringify(taskList));
			}
		}
		
		//Display buttons
		if(taskList[i].done == true )
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
	}
	
	
	/*
	alert("op");
	//make only one button click function with many conditionals
	$('#day').on('click',function(){
		//redirect
		alert("button");
	});
	
	$('#box').on('click',function(){
		alert("check and uncheck");
	});
	
*/
}

function done(name){
//checking if local storage is competable with browser
	if(window.localStorage)
	{
		taskList = JSON.parse(window.localStorage.getItem('taskList'));
	}
	
	//checking if array is empty
	if(null !== taskList)
	{
	//display buttons
		for(var i=0;i<=taskList.length;i++)
		{
			//checking for name similarity
			if(taskList[i].day == name)
			{
				if(taskList[i].done == true)
				{
					taskList[i].done=false;
					if(window.localStorage)
					{
						window.localStorage.setItem('taskList',JSON.stringify(taskList));
					}
					//alert(name + " it is done");
				}
				else
				{
					taskList[i].done=true;
					if(window.localStorage)
					{
						window.localStorage.setItem('taskList',JSON.stringify(taskList));
					}
					//alert(name + " it is not done");
				}
				$("#taskList").empty();
				showall();
				//setTimeout("location.reload(true);", 1);
			}
		}
	}
	else
	{
		//number of days
		var N  = 30;
		taskList = new Array();
		
		for(var i=0;i<=N;i++)
		{
		    var $day = "day" + i.toString();
			taskList.push({day:$day,done:true});
			if(window.localStorage)
			{
				window.localStorage.setItem('taskList',JSON.stringify(taskList));
			}
		}
		
		//Display buttons
		if(taskList[i].done == true)
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)" data-transition="flip" data-direction="reverse">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
	}

}


function start(name){
	
	if(window.localStorage)
	{
		workOut = JSON.parse(window.localStorage.getItem('workOut'));
	}
	if(null !== workOut)
	{
		workOut[0]=name;
		if(window.localStorage)
		{
			window.localStorage.setItem('workOut',JSON.stringify(workOut));
		}
	}
	else
	{
		workOut = new Array();
		workOut.push({work:name});
		if(window.localStorage)
		{
			window.localStorage.setItem('workOut',JSON.stringify(workOut));
		}
	}
	activities();
	window.location='#start';
	
	
}