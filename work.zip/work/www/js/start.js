var taskList = new Array();
var workOut = new Array();

function activities(){
    $("#NextSection").empty();
    var $taskListt = $('#NextSection');
	if(window.localStorage)
	{
		workOut = JSON.parse(window.localStorage.getItem('workOut'));
	}
	if(null !== workOut)
	{
	    var Num = parseInt(workOut);
		//converting to number
        var Number = Num*10;		
		var newTaskt = '<img src="img/sb-abs-push-throughs.gif" alt="HTML5 Icon" style="width:80%;height:80%;margin-top:5px;margin-left:10%;"><br><p id="pic">Do '+Number+' of These</p><br><Button name="'+Num+'" id="addNewTask" onclick="next(name,1)"  data-transition="flip" data-direction="reverse">Next</button>'; 
		$taskListt.append(newTaskt);
	

	}
	else
	{
		window.location='#workouts';
	}
	//use workOut[0] to search for a set off exercises the little database i am gonna make here
}

function next(name,names){
if(window.localStorage)
	{
		workOut = JSON.parse(window.localStorage.getItem('workOut'));
	}
	if(null !== workOut)
	{
	    var Num = (workOut);
		//converting to number so that i can determine number of exercises per day, or i could make a string list
        var Number = Num*10;		
if(names=="4"){
alert("Workout done for the day");
$("#NextSection").empty();
donee(name);
//setTimeout("location.reload(true);", 1);
window.location='#index';
}
else if(names=="1")
{
	$("#NextSection").empty();
	var newTaskt = '<img src="img/sb-abs-bicycle.gif" alt="HTML5 Icon" style="width:80%;height:80%;margin-top:5px;margin-left:10%;"><br><p id="pic">Do '+Number+' of These</p><br><Button name="'+Num+'" id="addNewTask" onclick="next(name,2)" data-transition="flip" data-direction="reverse" >Next</button>'; 
	$("#NextSection").append(newTaskt);
}
else if(names=="2")
{
	$("#NextSection").empty();
	var newTaskt = '<img src="img/sb-abs-reach-toes.gif" alt="HTML5 Icon" style="width:80%;height:80%;margin-top:5px;margin-left:10%;"><br><p id="pic">Do '+Number+' of These</p><br><Button name="'+Num+'" id="addNewTask" onclick="next(name,3)" data-transition="flip" data-direction="reverse">Next</button>'; 
	$("#NextSection").append(newTaskt);
}
else if(names=="3")
{
	$("#NextSection").empty();
	var newTaskt = '<img src="img/sb-abs-kick-ups.gif" alt="HTML5 Icon" style="width:80%;height:80%;margin-top:5px;margin-left:10%;"><br><p id="pic">Do '+Number+' of These</p><br><Button name="'+Num+'" id="addNewTask" onclick="next(name,4)" data-transition="flip" data-direction="reverse">Next</button>'; 
	$("#NextSection").append(newTaskt);
}
else{}
}
else
{
	window.location='#workouts';
}



	
}

function donee(name){
//checking if local storage is competable with browser
	if(window.localStorage)
	{
		taskList = JSON.parse(window.localStorage.getItem('taskList'));
	}
	
	//checking if array is empty
	if(null !== taskList)
	{
	//display buttons
		for(var i=0;i<=taskList.length;i++)
		{
			//checking for name similarity
			if(i == name)
			{
				if(taskList[i].done == true)
				{
					taskList[i].done=false;
					if(window.localStorage)
					{
						window.localStorage.setItem('taskList',JSON.stringify(taskList));
					}
					//alert(name + " it is done");
				}
				else
				{
					taskList[i].done=true;
					if(window.localStorage)
					{
						window.localStorage.setItem('taskList',JSON.stringify(taskList));
					}
					//alert(name + " it is not done");
				}
				window.location='index.html';
			}
		}
	}
	else
	{
		//number of days
		var N  = 30;
		taskList = new Array();
		
		for(var i=0;i<=N;i++)
		{
		    var $day = "day" + i.toString();
			taskList.push({day:$day,done:true});
			if(window.localStorage)
			{
				window.localStorage.setItem('taskList',JSON.stringify(taskList));
			}
		}
		
		//Display buttons
		if(taskList[i].done == true)
			{
				var newTask = '<button id="day" name="' + i + '" class="done" onclick="start(name)">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
			else
			{
				//maybe make a class to change them all
				var newTask = '<button id="day" name="' + i + '" onclick="start(name)">' + taskList[i].day +'<button id="done" name="' + taskList[i].day + '" onclick="done(name)">Done</button></button><br>'; 
				$taskList.append(newTask);
			}
	}

}
